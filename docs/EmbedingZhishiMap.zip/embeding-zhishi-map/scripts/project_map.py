"""从已核对的真实向量生成二维或三维 MDS 数据，不加载模型。"""
import argparse
import copy
from pathlib import Path
import time
import warnings
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.distance import pdist, squareform
from scipy.stats import spearmanr
from sklearn.manifold import smacof
from map_data import source_data, read_json, write_json, verify_record, validate_vectors


def quality(points, distances):
    projected = squareform(pdist(points))
    pairs = np.triu_indices(len(points), 1)
    error = np.sqrt(np.sum((projected[pairs] - distances[pairs]) ** 2) / np.sum(distances[pairs] ** 2))
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        correlation = float(spearmanr(distances[pairs], projected[pairs]).statistic)
    k = min(3, len(points) - 1)
    original_neighbors = distances.copy()
    new_neighbors = projected.copy()
    np.fill_diagonal(original_neighbors, np.inf)
    np.fill_diagonal(new_neighbors, np.inf)
    retained = np.mean([len(set(np.argsort(original_neighbors[i], kind="stable")[:k]) &
                               set(np.argsort(new_neighbors[i], kind="stable")[:k])) / k
                        for i in range(len(points))])
    return projected, {"normalized_distance_error": float(error),
                       "distance_rank_correlation": correlation if np.isfinite(correlation) else None,
                       "top3_neighbor_retention": float(retained), "neighbor_k": k}


def refine(points, distances):
    count, dimension = points.shape
    a, b = np.triu_indices(count, 1)
    target = distances[a, b]

    def residual(flat):
        p = flat.reshape(count, dimension)
        return np.linalg.norm(p[a] - p[b], axis=1) - target

    def jacobian(flat):
        p = flat.reshape(count, dimension)
        delta = p[a] - p[b]
        direction = delta / np.maximum(np.linalg.norm(delta, axis=1, keepdims=True), 1e-12)
        matrix = np.zeros((len(a), count * dimension))
        rows = np.arange(len(a))
        for axis in range(dimension):
            matrix[rows, a * dimension + axis] = direction[:, axis]
            matrix[rows, b * dimension + axis] = -direction[:, axis]
        return matrix

    result = least_squares(residual, points.ravel(), jac=jacobian, max_nfev=200,
                           ftol=1e-10, xtol=1e-10, gtol=1e-10)
    return result.x.reshape(count, dimension), {"success": bool(result.success),
                                               "status": int(result.status), "nfev": int(result.nfev)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--vectors", type=Path, required=True)
    parser.add_argument("--record", type=Path)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--dimensions", type=int, choices=[2, 3], nargs="+", default=[2, 3])
    parser.add_argument("--starts", type=int, default=8)
    parser.add_argument("--max-iter", type=int, default=3000)
    parser.add_argument("--seed", type=int, default=2642)
    parser.add_argument("--refine", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    if args.starts < 1 or args.max_iter < 1:
        raise ValueError("起点数与迭代上限至少为 1")
    data = source_data(args.source)
    record = read_json(args.record or args.vectors.parent / "embedding-record.json")
    verify_record(data, args.vectors, record)
    vectors = np.load(args.vectors, allow_pickle=False)
    validate_vectors(vectors, len(data["nodes"]), record["dimension"])
    vectors = vectors.astype(np.float64)
    vectors /= np.linalg.norm(vectors, axis=1, keepdims=True)
    distances = squareform(pdist(vectors))
    if np.max(distances) < 1e-12:
        raise ValueError("全部向量相同，无法定义保距误差；先改进知识定义或只制作关系图")
    similarities = np.clip(vectors @ vectors.T, -1, 1)
    count = len(vectors)
    center = np.eye(count) - np.ones((count, count)) / count
    gram = -0.5 * center @ distances ** 2 @ center
    eigenvalues, eigenvectors = np.linalg.eigh(gram)
    order = np.argsort(eigenvalues)[::-1]
    dimensions = list(dict.fromkeys(args.dimensions))
    for dimension in dimensions:
        filename = "knowledge-map.json" if dimension == 2 else "knowledge-map-3d.json"
        if (args.out_dir / filename).exists() and not args.overwrite:
            raise FileExistsError("坐标文件已存在；保留旧版，使用新输出目录或 --overwrite：" + filename)
    for dimension in dimensions:
        start = time.perf_counter()
        used = order[:dimension]
        initial = eigenvectors[:, used] * np.sqrt(np.maximum(eigenvalues[used], 0))
        initial = np.pad(initial, ((0, 0), (0, dimension - initial.shape[1])))
        if np.linalg.norm(initial) < 1e-12:
            initial = np.random.default_rng(args.seed).normal(0, 0.3, (count, dimension))
        candidates = []
        best, best_error = None, np.inf
        for run in range(args.starts):
            seed = args.seed + run
            guess = initial if run == 0 else np.random.default_rng(seed).normal(0, 0.5, (count, dimension))
            points, _, iterations = smacof(distances, metric=True, n_components=dimension,
                                           init=guess, n_init=1, max_iter=args.max_iter, eps=1e-9,
                                           random_state=seed, normalized_stress=False, return_n_iter=True)
            points -= points.mean(axis=0)
            _, metrics = quality(points, distances)
            error = metrics["normalized_distance_error"]
            candidates.append({"seed": seed, "initialization": "classical" if run == 0 else "random",
                               "error": error, "iterations": int(iterations),
                               "reached_iteration_limit": iterations >= args.max_iter})
            if error < best_error:
                best, best_error = points.copy(), error
        refinement = None
        if args.refine:
            improved, refinement = refine(best, distances)
            improved -= improved.mean(axis=0)
            _, metrics = quality(improved, distances)
            refinement["error"] = metrics["normalized_distance_error"]
            if refinement["error"] < best_error:
                best = improved
        projected, metrics = quality(best, distances)
        projection = {**metrics, "algorithm": "metric MDS / SMACOF", "dimensions": dimension,
                      "baseline_error": candidates[0]["error"], "candidates": candidates,
                      "refinement": refinement, "max_iter": args.max_iter, "eps": 1e-9,
                      "normalized_stress": False, "seed": args.seed,
                      "centered_gram_rank": int(np.sum(eigenvalues > 1e-8)),
                      "axes": "投影坐标，不表示难度、时长或掌握程度",
                      "global_optimum_proven": False, "seconds": round(time.perf_counter() - start, 3)}
        output = copy.deepcopy(data)
        output["nodes"] = [{**n, **dict(zip("xyz"[:dimension], map(float, best[i])))}
                           for i, n in enumerate(data["nodes"])]
        output.update({"similarities": similarities.tolist(), "distances": distances.tolist(),
                       "projected_distances": projected.tolist(), "embedding": record, "projection": projection})
        filename = "knowledge-map.json" if dimension == 2 else "knowledge-map-3d.json"
        write_json(args.out_dir / filename, output)
        print(f"{dimension}D：{count} 点，距离相对误差 {metrics['normalized_distance_error']:.3%}", flush=True)


if __name__ == "__main__":
    main()
