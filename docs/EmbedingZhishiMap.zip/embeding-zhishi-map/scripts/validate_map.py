"""核对嵌入、距离、投影与 HTML 数据；不能代替浏览器实测。"""
import argparse
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import numpy as np
from scipy.spatial.distance import pdist, squareform
from map_data import source_data, read_json, embedding_input, verify_record, validate_vectors


class ResourceParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.external = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in ("script", "link", "img", "iframe", "source") and ("src" in attrs or "href" in attrs):
            self.external.append([tag, attrs.get("src", attrs.get("href"))])


def check_projection(data, expected_distances, dimension):
    positions = np.array([[n[axis] for axis in "xyz"[:dimension]] for n in data["nodes"]])
    if not np.isfinite(positions).all():
        raise ValueError("坐标包含非有限数值")
    actual = squareform(pdist(positions))
    if not np.allclose(expected_distances, data["distances"], atol=1e-10):
        raise ValueError("原始距离与向量不一致")
    if not np.allclose(actual, data["projected_distances"], atol=1e-10):
        raise ValueError("空间距离与坐标不一致")
    pairs = np.triu_indices(len(positions), 1)
    error = float(np.sqrt(np.sum((actual[pairs] - expected_distances[pairs]) ** 2) /
                          np.sum(expected_distances[pairs] ** 2)))
    if abs(error - data["projection"]["normalized_distance_error"]) > 1e-10:
        raise ValueError("记录的距离误差与复算不一致")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--vectors", type=Path, required=True)
    parser.add_argument("--record", type=Path)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--data3d", type=Path)
    parser.add_argument("--html", type=Path)
    args = parser.parse_args()
    source = source_data(args.source)
    record = read_json(args.record or args.vectors.parent / "embedding-record.json")
    verify_record(source, args.vectors, record)
    vectors = np.load(args.vectors, allow_pickle=False)
    validate_vectors(vectors, len(source["nodes"]), record["dimension"])
    vectors = vectors.astype(np.float64)
    vectors /= np.linalg.norm(vectors, axis=1, keepdims=True)
    distances = squareform(pdist(vectors))
    data = read_json(args.data)
    if embedding_input(source) != embedding_input(data):
        raise ValueError("地图与源数据的知识定义不一致")
    if source["edges"] != data["edges"]:
        raise ValueError("地图中的人工关系被改变")
    if not np.allclose(vectors @ vectors.T, data["similarities"], atol=1e-10):
        raise ValueError("相似度不是归一化向量的点积")
    check_projection(data, distances, 2)
    data3d = read_json(args.data3d) if args.data3d else None
    if data3d:
        if embedding_input(source) != embedding_input(data3d):
            raise ValueError("三维地图与源数据不一致")
        check_projection(data3d, distances, 3)
    if args.html:
        text = args.html.read_text(encoding="utf-8")
        resources = ResourceParser()
        resources.feed(text)
        if resources.external:
            raise ValueError("单文件页面含外链资源：" + str(resources.external))
        for element_id, expected in [("am3-data", data), ("am3-data-3d", data3d)]:
            script = re.search(r'<script[^>]*id="' + element_id + r'"[^>]*>(.*?)</script>', text, re.S)
            if not script or json.loads(script.group(1)) != expected:
                raise ValueError("HTML 内嵌数据与 JSON 不同：" + element_id)
        for attrs, code in re.findall(r"<script([^>]*)>(.*?)</script>", text, re.S):
            if "application/json" not in attrs and re.search(r"\b(?:fetch|XMLHttpRequest|WebSocket)\s*\(", code):
                raise ValueError("页面程序包含网络调用")
    print("数据检查通过：", len(source["nodes"]), "节点，", len(source["edges"]), "关系；实际界面需另行检查。")


if __name__ == "__main__":
    main()
