"""本地 WeMM 文本编码；缓存必须匹配文本、模型和编码方式。"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import time

from map_data import source_data, embedding_input, file_hash, read_json, write_json, validate_vectors


def model_fingerprint(folder):
    # 小文件核对内容；大权重只记文件状态，不冒称完整权重内容哈希。
    small = []
    weights = []
    for path in sorted(folder.iterdir()):
        if not path.is_file():
            continue
        if path.suffix in (".json", ".py", ".jinja"):
            small.append([path.name, file_hash(path)])
        elif path.suffix in (".safetensors", ".bin"):
            info = path.stat()
            weights.append([path.name, info.st_size, info.st_mtime_ns])
    if not (folder / "config.json").is_file() or not weights:
        raise ValueError("模型目录缺少 config.json 或本地权重文件")
    encoded = json.dumps([small, weights], separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--weights", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--cache-dir", type=Path)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--dtype", choices=["auto", "bfloat16", "float16", "float32"], default="auto")
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--expected-dim", type=int, default=2048)
    parser.add_argument("--recompute", action="store_true")
    args = parser.parse_args()
    if args.batch_size < 1:
        raise ValueError("batch size 至少为 1")
    data = source_data(args.source)
    ids, texts, input_hash = embedding_input(data)
    weights = args.weights.resolve(strict=True)
    fingerprint = model_fingerprint(weights)
    dtype_name = args.dtype if args.dtype != "auto" else ("float32" if args.device == "cpu" else "bfloat16")
    cache_identity = {"input_sha256": input_hash, "model_fingerprint": fingerprint,
                      "encoding": "encode_document; name + description; float32 L2 normalization",
                      "dimension": args.expected_dim, "dtype": dtype_name}
    args.out_dir.mkdir(parents=True, exist_ok=True)
    vector_path = args.out_dir / "embeddings.npy"
    record_path = args.out_dir / "embedding-record.json"
    import numpy as np
    if (vector_path.exists() or record_path.exists()) and not args.recompute:
        if not vector_path.exists() or not record_path.exists():
            raise ValueError("向量缓存不完整；使用新输出目录或 --recompute")
        record = read_json(record_path)
        if any(record.get(k) != v for k, v in cache_identity.items()) or record.get("node_ids") != ids:
            raise ValueError("缓存与输入或模型不匹配；使用新输出目录或 --recompute")
        validate_vectors(np.load(vector_path, allow_pickle=False), len(ids), args.expected_dim)
        if record.get("embeddings_sha256") != file_hash(vector_path):
            raise ValueError("缓存向量内容变了，不能继续复用")
        print("复用已核对的真实向量，不加载模型。", flush=True)
        return
    # 在 transformers 等库导入之前设置离线和任务自己的缓存位置。
    cache_dir = (args.cache_dir or args.out_dir / "model-cache").resolve()
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ["HF_HOME"] = str(cache_dir)
    os.environ["HF_MODULES_CACHE"] = str(cache_dir / "modules")
    os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    import importlib.metadata as metadata
    import torch
    from sentence_transformers import SentenceTransformer
    if args.device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("当前解释器的 CUDA 不可用；确认环境或明确选择 CPU")
    print("加载本地 WeMM，纯文本编码；不会下载模型或调用 API。", flush=True)
    start = time.perf_counter()
    model = SentenceTransformer(str(weights), trust_remote_code=True, local_files_only=True,
                                device=args.device, model_kwargs={"dtype": getattr(torch, dtype_name)})
    model.eval()
    with torch.inference_mode():
        vectors = model.encode_document(texts, batch_size=args.batch_size,
                                       normalize_embeddings=True, convert_to_numpy=True,
                                       show_progress_bar=False).astype(np.float32)
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    if np.any(norms < 1e-12):
        raise ValueError("模型返回零向量")
    vectors = (vectors / norms).astype(np.float32)
    validate_vectors(vectors, len(ids), args.expected_dim)
    temporary = vector_path.with_suffix(".tmp")
    with temporary.open("wb") as stream:
        np.save(stream, vectors, allow_pickle=False)
    temporary.replace(vector_path)
    packages = ["torch", "transformers", "sentence-transformers", "numpy", "qwen-vl-utils", "accelerate"]
    record = {**cache_identity, "model": "WeMM-Embedding-2B", "weights": str(weights),
              "node_ids": ids, "device": args.device, "batch_size": args.batch_size,
              "embeddings_sha256": file_hash(vector_path),
              "fingerprint_policy": "small-file SHA256 plus weight filename/size/mtime; not full weight SHA256",
              "packages": {name: metadata.version(name) for name in packages},
              "seconds": round(time.perf_counter() - start, 3), "paid_api_requests": 0}
    write_json(record_path, record)
    del model
    if args.device.startswith("cuda"):
        torch.cuda.empty_cache()
    print("向量已保存：", vectors.shape, str(vector_path), flush=True)


if __name__ == "__main__":
    main()
