"""把地图 JSON 和技能内的前端资产打包成一个 HTML；本步骤仅需标准库。"""
import argparse
import html
import json
import math
from pathlib import Path
import re
from map_data import source_data, read_json


def check_positions(data, dimension):
    for node in data["nodes"]:
        for axis in "xyz"[:dimension]:
            value = node.get(axis)
            if not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ValueError(node["id"] + " 的坐标缺失或不是有限数值：" + axis)


def json_text(value):
    # 避免资料文字中的 </script> 提前结束数据块。
    return json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":")).replace("<", "\\u003c")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    inputs = parser.add_mutually_exclusive_group(required=True)
    inputs.add_argument("--data", type=Path, help="二维地图 JSON")
    inputs.add_argument("--source", type=Path, help="仅制作人工关系图，不计算或假造语义坐标")
    parser.add_argument("--data3d", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--title")
    args = parser.parse_args()
    data = source_data(args.data or args.source)
    data3d = None
    if args.source:
        if args.data3d:
            raise ValueError("关系图模式不能附加语义三维数据")
        data["mode"] = "relations-only"
        data["embedding"] = {"model": "未使用嵌入", "dimension": 0, "encoding": "仅人工关系"}
        data["projection"] = {}
    else:
        check_positions(data, 2)
        for field in ("embedding", "projection", "distances", "similarities", "projected_distances"):
            if field not in data:
                raise ValueError("二维地图缺少 " + field)
        if args.data3d:
            data3d = read_json(args.data3d)
            check_positions(data3d, 3)
            if [n["id"] for n in data["nodes"]] != [n["id"] for n in data3d["nodes"]]:
                raise ValueError("三维与二维的节点 ID 顺序不一致")
            if data["embedding"].get("input_sha256") != data3d["embedding"].get("input_sha256"):
                raise ValueError("三维与二维使用的输入文本不同")
            if data["distances"] != data3d["distances"]:
                raise ValueError("三维与二维原始距离不同，不能混用")
    title = args.title or data["title"]
    count = len(data["nodes"])
    edge_count = len(data["edges"])
    assets = Path(__file__).resolve().parent.parent / "assets"
    replacements = {"TITLE": html.escape(title), "SCOPE": html.escape(data["scope"]),
                    "NODE_COUNT": str(count), "EDGE_COUNT": str(edge_count),
                    "DATA_2D": json_text(data), "DATA_3D": json_text(data3d),
                    "FLIGHT_SCRIPT": (assets / "flight-3d.js").read_text(encoding="utf-8"),
                    "MAP_SCRIPT": (assets / "map-view.js").read_text(encoding="utf-8")}
    template = (assets / "map-shell.html").read_text(encoding="utf-8")
    # 一次替换，数据中的 {{...}} 不会被再次当成模板处理。
    output = re.sub(r"\{\{([A-Z0-9_]+)\}\}", lambda match: replacements[match.group(1)], template)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(output, encoding="utf-8")
    print("单文件页面已生成：", args.out)


if __name__ == "__main__":
    main()
