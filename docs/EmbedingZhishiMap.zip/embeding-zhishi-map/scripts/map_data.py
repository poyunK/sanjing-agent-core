"""知识地图共有的数据约定；不导入模型，不执行资料里的内容。"""
from pathlib import Path
import hashlib
import json
import re


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(text, encoding="utf-8")
    temporary.replace(path)


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def source_data(path):
    data = read_json(path)
    if not isinstance(data, dict) or not isinstance(data.get("nodes"), list):
        raise ValueError("源数据需要 nodes 列表")
    if len(data["nodes"]) < 2:
        raise ValueError("此网络模板至少需要两个知识点")
    ids = []
    for node in data["nodes"]:
        node_id = node.get("id", "")
        if not isinstance(node_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]+", node_id):
            raise ValueError("知识点 id 使用不含空格的英文字母、数字、下划线或连字符")
        if node_id in ids:
            raise ValueError("重复知识点 id：" + node_id)
        ids.append(node_id)
        for field in ("name", "description"):
            if not isinstance(node.get(field), str) or not node[field].strip():
                raise ValueError(node_id + " 缺少 " + field)
        chapters = node.get("chapters", node.get("chapter", "0"))
        if isinstance(chapters, (int, str)):
            if re.search(r"[-−]\s*\d", str(chapters)):
                raise ValueError("章节编号不能为负；0 表示未分章")
            chapters = re.findall(r"\d+", str(chapters))
        if not isinstance(chapters, list) or not chapters:
            raise ValueError(node_id + " 的章节格式无效")
        numbers = [int(c) for c in chapters]
        if any(c < 0 for c in numbers):
            raise ValueError("章节编号不能为负；0 表示未分章")
        numbers = list(dict.fromkeys(numbers))
        if 0 in numbers and len(numbers) > 1:
            raise ValueError("未分章不能同时填已知章节")
        node["chapter"] = "、".join(map(str, numbers))
        node.setdefault("example", "")
    normalized = []
    for edge in data.get("edges", []):
        if isinstance(edge, dict):
            edge = [edge.get("source", edge.get("from")),
                    edge.get("target", edge.get("to")),
                    edge.get("label", edge.get("relation")),
                    edge.get("type", "用于")]
        if not isinstance(edge, list) or len(edge) != 4:
            raise ValueError("关系需要 [起点, 终点, 用途文字, 类型]")
        if edge[0] not in ids or edge[1] not in ids:
            raise ValueError("关系端点不存在：" + str(edge[:2]))
        if not all(isinstance(v, str) and v.strip() for v in edge):
            raise ValueError("关系字段必须是非空字符串")
        if edge in normalized:
            raise ValueError("存在完全重复的关系：" + str(edge))
        normalized.append(edge)
    data["edges"] = normalized
    rows = data.get("layout", {}).get("rows")
    if rows is not None:
        if not isinstance(rows, list) or not rows or any(not isinstance(r, list) or not 1 <= len(r) <= 3 for r in rows):
            raise ValueError("当前阅读模板的 rows 每行需要 1～3 个 id")
        arranged = [node_id for row in rows for node_id in row]
        if len(arranged) != len(ids) or set(arranged) != set(ids):
            raise ValueError("layout.rows 必须包含全部节点，每个 id 正好一次")
    data.setdefault("title", "语义知识地图")
    data.setdefault("scope", "用户提供的学习资料")
    return data


def embedding_input(data):
    ids = [n["id"] for n in data["nodes"]]
    texts = [n["name"] + "。" + n["description"] for n in data["nodes"]]
    payload = {"node_ids": ids, "texts": texts, "format": "name + description"}
    encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return ids, texts, hashlib.sha256(encoded).hexdigest()


def verify_record(data, vectors_path, record):
    ids, _, input_hash = embedding_input(data)
    if record.get("node_ids") != ids or record.get("input_sha256") != input_hash:
        raise ValueError("向量记录与当前知识点文本或 ID 顺序不匹配")
    if record.get("embeddings_sha256") != file_hash(vectors_path):
        raise ValueError("向量文件哈希与编码记录不匹配")


def validate_vectors(vectors, count, expected_dimension=None):
    import numpy as np
    if vectors.ndim != 2 or vectors.shape[0] != count:
        raise ValueError("向量行数与节点数不一致")
    if expected_dimension is not None and vectors.shape[1] != expected_dimension:
        raise ValueError("实际向量维数不符合编码记录")
    if not np.isfinite(vectors).all():
        raise ValueError("向量含 NaN 或无穷数")
    norms = np.linalg.norm(vectors.astype(np.float64), axis=1)
    if np.any(norms < 1e-12) or not np.allclose(norms, 1, atol=1e-5):
        raise ValueError("向量必须为非零的 L2 归一化向量")

