
  (()=>{
    const root=document.getElementById('agent-map-v03');
    const data=JSON.parse(root.querySelector('#am3-data').textContent);
    const data3d=JSON.parse(root.querySelector('#am3-data-3d').textContent);
    const byId3d=new Map((data3d?.nodes||[]).map(n=>[n.id,n]));
    const semanticAvailable=data.mode!=="relations-only",threeAvailable=!!data3d?.nodes?.length;
    layoutSelectFix();
    function layoutSelectFix(){root.querySelector('option[value="semantic"]').disabled=!semanticAvailable;root.querySelector('option[value="semantic3d"]').disabled=!threeAvailable;}
    const nodes=data.nodes, edges=data.edges;
    const byId=new Map(nodes.map((n,i)=>[n.id,{...n,index:i,code:'N'+String(i+1).padStart(2,'0')}]));
    const layoutSelect=root.querySelector('#am3-layout'),nodeSelect=root.querySelector('#am3-node');
    const svg=root.querySelector('#am3-chart'),plot=root.querySelector('.map-plot');
    const NS='http://www.w3.org/2000/svg';
    let saved={};try{saved=JSON.parse(localStorage.getItem('embedding-knowledge-map:'+data.scope+':'+(data.embedding.input_sha256||data.mode))||'{}');}catch{}
    let selected=byId.has(saved.selectedNode)?saved.selectedNode:(byId.has(data.reading?.node)?data.reading.node:nodes[0].id);
    let layout=(saved.layout==='semantic'&&semanticAvailable||saved.layout==='semantic3d'&&threeAvailable)?saved.layout:'relations';
    const rotationControls=root.querySelector('#am3-rotation');
    let comparison=byId.has(saved.comparisonNode)?saved.comparisonNode:null;
    let polarGeometry=null,flight=null;
    const measureCanvas=document.createElement('canvas');
    const measure=measureCanvas.getContext('2d');
    function textWidth(t){measure.font='14px '+getComputedStyle(root).fontFamily;return measure.measureText(t).width;}
    function S(tag,attrs={},text,parent=svg){const e=document.createElementNS(NS,tag);for(const [k,v] of Object.entries(attrs))e.setAttribute(k,v);if(text!==undefined)e.textContent=text;parent.append(e);return e;}
    function H(tag,text,className,parent){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(className)e.className=className;parent.append(e);return e;}
    function wrap(text,max){const out=[];let line='';for(const ch of text){if(line&&textWidth(line+ch)>max){out.push(line);line=ch;}else line+=ch;}if(line)out.push(line);return out;}
    for(const n of byId.values()){const option=document.createElement('option');option.value=n.id;option.textContent=n.code+' '+n.name;nodeSelect.append(option);}
    root.querySelector('#am3-meta').textContent=`${nodes.length} 个知识点 · ${edges.length} 条明确关系 · ${semanticAvailable?data.embedding.model+' '+data.embedding.dimension+' 维':'人工关系；未计算语义距离'}`;
    for(const [a,b,label,type] of edges){const row=H('div',undefined,undefined,root.querySelector('#am3-relations'));row.textContent=byId.get(a).name+' —'+label+'→ '+byId.get(b).name+' ['+type+']';}
    const projection=data.projection;
    const chapterLegend=root.querySelector('#am3-chapter-legend');
    const chapterColor=chapter=>'var(--am3-chapter-'+chapter+')';
    const softChapter=chapter=>'color-mix(in srgb,'+chapterColor(chapter)+' 24%,var(--background))';
    const chaptersOf=n=>(String(n.chapter).match(/\d+/g)||['0']).map(Number);
    const chapterLabel=n=>n.chapter==='0'?'未分章':'第 '+n.chapter+' 章';
    const presentChapters=[...new Set(nodes.flatMap(chaptersOf))].sort((a,b)=>a-b);
    const baseColors=['#ffb0da','#73d38e','#6e9fff','#f69a55','#63c3e2','#f5d566','#b8a6ed','#b9bd7a','#b2d1ad','#aeb8dc'];
    root.style.setProperty('--am3-chapter-0','#b8b6c5');
    const maxChapter=Math.max(1,...presentChapters);
    for(let c=1;c<=maxChapter;c++){const configured=data.chapter_colors?.[c];const color=/^#[a-f0-9]{6}$/i.test(configured||'')?configured:baseColors[c-1]||`hsl(${(c*137.508)%360} 42% 72%)`;root.style.setProperty('--am3-chapter-'+c,color);}
    const numberText=(value,digits=3)=>Number.isFinite(value)?value.toFixed(digits):'不可定义';
    for(const chapter of presentChapters){
      const key=H('span',undefined,'map-chapter-key',chapterLegend);
      const swatch=S('svg',{width:16,height:12,'aria-hidden':'true'},undefined,key);
      S('rect',{x:0,y:0,width:16,height:12,fill:chapterColor(chapter)},undefined,swatch);
      H('span',chapter===0?'未分章':'第 '+chapter+' 章',undefined,key);
    }
    H('span','跨章按字段顺序分色；两章时左、右各半',undefined,chapterLegend);
    const record=root.querySelector('#am3-record');
    H('p',`输入：知识名称＋定义；${data.embedding.model}；${data.embedding.dimension} 维；${data.embedding.encoding}。`,undefined,record);
    if(semanticAvailable){
      H('p',`二维距离相对误差 ${numberText(projection.normalized_distance_error*100,2)}%；距离排序相关 ${numberText(projection.distance_rank_correlation)}；原始前 ${projection.neighbor_k||3} 近邻保留 ${numberText(projection.top3_neighbor_retention*100,1)}%。`,undefined,record);
      H('p','相似度是归一化向量点积，原始距离是归一化向量欧氏距离。圆点是保存坐标，文字框可以避让。相似不表示前置、难度或掌握程度。',undefined,record);
      if(threeAvailable)H('p',`三维空间距离相对误差 ${numberText(data3d.projection.normalized_distance_error*100,3)}%；排序相关 ${numberText(data3d.projection.distance_rank_correlation)}；近邻保留 ${numberText(data3d.projection.top3_neighbor_retention*100,1)}%。相机移动不改变空间误差。`,undefined,record);
    }else H('p','本页仅显示人工关系，没有计算或模拟语义向量、距离与坐标。',undefined,record);
    H('p','章节颜色只表示归属，不进入嵌入输入；多起点或迭代停止不构成全局最优证明。',undefined,record);
    function persist(){try{localStorage.setItem('embedding-knowledge-map:'+data.scope+':'+(data.embedding.input_sha256||data.mode),JSON.stringify({selectedNode:selected,layout,comparisonNode:comparison}));}catch{}}
    function updateDetail(){
      nodeSelect.value=selected;layoutSelect.value=layout;
      const n=byId.get(selected),detail=root.querySelector('#am3-selected');detail.replaceChildren();
      H('div',n.code+' '+n.name+' · '+chapterLabel(n),'map-detail-title',detail);
      H('p',n.description,undefined,detail);H('code',n.example,undefined,detail);
      const stats=H('div',undefined,'map-stats text-small tabular-nums',detail);
      const p3=byId3d.get(n.id);
      H('span',semanticAvailable?(layout==='semantic3d'&&p3?`三维坐标 (${p3.x.toFixed(3)}, ${p3.y.toFixed(3)}, ${p3.z.toFixed(3)})`:`语义坐标 (${n.x.toFixed(3)}, ${n.y.toFixed(3)})`):'人工阅读布局，位置不表示语义',undefined,stats);
      H('span',`关联 ${edges.filter(e=>e[0]===n.id||e[1]===n.id).length} 条明确关系`,undefined,stats);
      if(n.sources?.length)H('p','来源：'+n.sources.map(s=>typeof s==='string'?s:[s.file,s.section,s.page,s.line].filter(v=>v!==undefined).join(' · ')).join('；'),undefined,detail);
      const pairs=root.querySelector('#am3-pairs');pairs.replaceChildren();
      if(!semanticAvailable){comparison=null;root.querySelector('#am3-comparison').textContent='';return;}
      const nearest=Array.from(byId.values()).filter(m=>m.id!==n.id).sort((a,b)=>data.distances[n.index][a.index]-data.distances[n.index][b.index]).slice(0,3);
      H('span',`原始向量最近的 ${nearest.length} 项：`,'text-small',pairs);
      for(const m of nearest){const b=H('button',m.name,'btn',pairs);b.type='button';b.addEventListener('click',()=>{comparison=m.id;updateComparison();persist();});}
      if(!comparison||comparison===selected)comparison=nearest[0]?.id||null;
      updateComparison();
    }
    function updateComparison(){
      const a=byId.get(selected),b=byId.get(comparison);if(!a||!b)return;
      const i=a.index,j=b.index;
      const distanceText=layout==='semantic3d'&&threeAvailable?`三维空间距离 ${data3d.projected_distances[i][j].toFixed(3)}`:`二维距离 ${data.projected_distances[i][j].toFixed(3)}`;
      root.querySelector('#am3-comparison').textContent=`与「${b.name}」比较：余弦相似度 ${data.similarities[i][j].toFixed(3)} · 原始距离 ${data.distances[i][j].toFixed(3)} · ${distanceText}`;
    }
    const rowOrder=data.layout?.rows||Array.from({length:Math.ceil(nodes.length/3)},(_,i)=>nodes.slice(i*3,i*3+3).map(n=>n.id));
    const columnCount=Math.max(...rowOrder.map(row=>row.length));
    function collision(a,b,gap=4){return a.x+a.w+gap>b.x&&b.x+b.w+gap>a.x&&a.y+a.h+gap>b.y&&b.y+b.h+gap>a.y;}
    function draw(){
      rotationControls.hidden=layout!=='semantic3d';
      document.body.dataset.view=layout;
      root.querySelector('#camera-status').hidden=layout!=='semantic3d';
      if(layout==='semantic3d'){
        const view=ensureFlight();view.setActive(true);view.setSelected(selected);view.draw();
        root.querySelector('#am3-legend').textContent='近大远小的透视观察 · 误差按三维空间距离计算：'+(data3d.projection.normalized_distance_error*100).toFixed(3)+'% · 天空方向与地面网格提供参照';
        root.querySelector('#am3-key').hidden=true;
        return;
      }
      if(flight)flight.setActive(false);
      svg.removeAttribute('data-renderer');svg.removeAttribute('data-visible-nodes');
      svg.style.height='';
      const width=Math.max(1,Math.round(plot.getBoundingClientRect().width)),compact=width<580;
      chapterLegend.hidden=false;
      const labelWidth=compact?52:Math.min(196,Math.max(70,(width-120)/columnCount));
      const boxes=new Map(),anchors=new Map();let height;
      const top=40;
      if(layout==='relations'){
        polarGeometry=null;
        const left=compact?28:30,right=compact?28:30;
        const step=(width-left-right)/columnCount;
        const gap=compact?94:118;
        height=rowOrder.length*gap+54;
        rowOrder.forEach((row,r)=>row.forEach((id,c)=>{
          const n=byId.get(id),x=left+step*(c+.5),y=top+r*gap;
          const lines=compact?[n.code]:wrap(n.name,labelWidth-12);
          const h=compact?44:lines.length*16+24,w=labelWidth;
          boxes.set(id,{x:x-w/2,y:y-h/2,w,h,lines,row:r,col:c});anchors.set(id,{x,y});
        }));
      }else{
        const xs=nodes.map(n=>n.x),ys=nodes.map(n=>n.y);
        const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);
        const margin=compact?42:88;
        const scale=(width-margin*2)/Math.max(maxX-minX,(maxX-minX<1e-9?maxY-minY:0),1e-6);
        const offsetX=(width-(maxX-minX)*scale)/2;
        const areaHeight=(maxY-minY)*scale;
        height=Math.max(compact?580:800,Math.ceil(areaHeight+margin*2+70));
        const originY=(height-areaHeight)/2;
        polarGeometry={x:offsetX-minX*scale,y:originY+maxY*scale,scale};
        for(const n of byId.values()){
          const x=offsetX+(n.x-minX)*scale,y=originY+(maxY-n.y)*scale;
          anchors.set(n.id,{x,y});
          const lines=compact?[n.code]:wrap(n.name,104);
          const w=compact?52:116,h=compact?44:lines.length*16+22;
          boxes.set(n.id,{x:x-w/2+10,y:y-h/2+10,w,h,lines});
        }
        // 只移动文字框避让；语义圆点保持原来的 MDS 坐标。
        const values=Array.from(boxes.values());
        for(let iter=0;iter<260;iter++){
          let changes=0;
          for(let i=0;i<values.length;i++)for(let j=i+1;j<values.length;j++){
            const a=values[i],b=values[j];if(!collision(a,b,6))continue;
            const dy=(a.y+a.h/2)-(b.y+b.h/2);
            const shift=(Math.min(a.y+a.h,b.y+b.h)-Math.max(a.y,b.y)+6)/2;
            a.y+=dy>=0?shift:-shift;b.y+=dy>=0?-shift:shift;changes++;
          }
          for(const b of values){b.x=Math.max(5,Math.min(width-b.w-5,b.x));b.y=Math.max(35,Math.min(height-b.h-38,b.y));}
          if(!changes)break;
        }
      }
      svg.setAttribute('viewBox',`0 0 ${width} ${height}`);svg.setAttribute('height',height);svg.replaceChildren();
      S('title',{},data.title+'：全部知识点和明确关系');
      S('desc',{},layout==='relations'?'文字框位置为人工阅读布局，不能用图上的距离比较语义。':'小圆点是 WeMM 向量的 MDS 投影坐标；文字框避让，用细线连接原坐标；二维投影存在失真。');
      const defs=S('defs');
      if(layout==='semantic')drawPolarGrid(polarGeometry,width,height,defs);
      const chapterFills=new Map();
      for(const n of byId.values()){
        const chapters=chaptersOf(n);
        if(chapters.length===1){chapterFills.set(n.id,softChapter(chapters[0]));continue;}
        const id='am3-chapters-'+n.id;
        const gradient=S('linearGradient',{id,x1:'0%',y1:'0%',x2:'100%',y2:'0%'},undefined,defs);
        chapters.forEach((chapter,i)=>{S('stop',{offset:(i/chapters.length*100)+'%','stop-color':softChapter(chapter)},undefined,gradient);S('stop',{offset:((i+1)/chapters.length*100)+'%','stop-color':softChapter(chapter)},undefined,gradient);});
        chapterFills.set(n.id,'url(#'+id+')');
      }
      for(const active of [false,true]){const marker=S('marker',{id:'am3-arrow-'+Number(active),viewBox:'0 0 8 8',refX:7,refY:4,markerWidth:6,markerHeight:6,orient:'auto-start-reverse'},undefined,defs);S('path',{d:'M1 1L7 4L1 7',fill:'none',stroke:active?'var(--viz-series-1)':'var(--muted-foreground)','stroke-width':1.3},undefined,marker);}
      S('text',{x:8,y:16},layout==='relations'?'全部关系 · 标签按阅读需要排布':'固定语义圆点 · 文字框避让');
      if(layout==='semantic'){
        S('text',{x:8,y:height-12,class:'axis-title','data-axis':'x'},'二维语义投影坐标 · 等比例显示');
        S('text',{x:8,y:32,class:'axis-title','data-axis':'y'},'位置旋转不改变距离');
      }
      const edgeGeometry=[];
      function rectPort(box,toward){const cx=box.x+box.w/2,cy=box.y+box.h/2,dx=toward.x-cx,dy=toward.y-cy;const scale=1/Math.max(Math.abs(dx)/(box.w/2),Math.abs(dy)/(box.h/2),0.001);return{x:cx+dx*scale,y:cy+dy*scale};}
      for(let k=0;k<edges.length;k++){
        const [a,b,label,type]=edges[k],aa=anchors.get(a),bb=anchors.get(b),active=a===selected||b===selected;
        let path,mid,points;
        if(layout==='relations'){
          const ab=boxes.get(a),bc=boxes.get(b);
          const source=rectPort(ab,bb),target=rectPort(bc,aa);
          if(Math.abs(ab.row-bc.row)<=1){const bend=(source.y+target.y)/2;path=`M${source.x} ${source.y}C${source.x} ${bend} ${target.x} ${bend} ${target.x} ${target.y}`;mid={x:(source.x+target.x)/2,y:bend};points=[source,mid,target];}
          else{
            const lane=(k%5-2)*4;
            const corridor=ab.col===bc.col?(ab.col<2?ab.x+ab.w+12+lane:ab.x-12+lane):(aa.x+bb.x)/2+lane;
            const sy=source.y+(target.y>=source.y?12:-12),ty=target.y+(target.y>=source.y?-12:12);
            path=`M${source.x} ${source.y}L${source.x} ${sy}L${corridor} ${sy}L${corridor} ${ty}L${target.x} ${ty}L${target.x} ${target.y}`;
            mid={x:corridor,y:(sy+ty)/2};points=[source,{x:corridor,y:sy},mid,{x:corridor,y:ty},target];
          }
        }else{
          const dx=bb.x-aa.x,dy=bb.y-aa.y,length=Math.max(1,Math.hypot(dx,dy));
          const end={x:bb.x-dx/length*7,y:bb.y-dy/length*7};
          path=`M${aa.x} ${aa.y}L${end.x} ${end.y}`;mid={x:(aa.x+bb.x)/2,y:(aa.y+bb.y)/2};points=[aa,mid,bb];
        }
        const p=S('path',{d:path,class:'map-edge'+(active?' active':'')+(type==='反馈'?' feedback':''),'marker-end':`url(#am3-arrow-${Number(active)})`,'data-edge':k});
        if(type==='对比')p.setAttribute('marker-start',`url(#am3-arrow-${Number(active)})`);
        p.setAttribute('data-tooltip',byId.get(a).name+' —'+label+'→ '+byId.get(b).name);
        edgeGeometry.push({k,label,type,mid,points,active});
      }
      if(layout==='semantic')for(const [id,b] of boxes){const a=anchors.get(id),p=rectPort(b,a);S('line',{x1:a.x,y1:a.y,x2:p.x,y2:p.y,class:'map-leader'});}
      const occupied=Array.from(boxes.values()).map(b=>({...b}));
      const labels=[];
      const sorted=edgeGeometry.slice().sort((a,b)=>Number(b.active)-Number(a.active));
      for(const edge of sorted){
        const content=compact?'R'+String(edge.k+1).padStart(2,'0'):edge.label;
        const w=textWidth(content)+8,h=18,candidates=[];
        for(const point of [edge.mid,...edge.points])for(const offset of [[0,0],[0,-16],[0,16],[24,0],[-24,0],[0,-32],[0,32],[36,-20],[-36,20]])candidates.push({x:point.x-w/2+offset[0],y:point.y-h/2+offset[1],w,h});
        // 留白区域的候选位置，只用于关系文字的避让，不会改变图中的知识坐标。
        for(let y=45;y<height-35;y+=22)for(let x=8;x<width-w-8;x+=24)candidates.push({x,y,w,h});
        const valid=candidates.filter(c=>c.x>=3&&c.x+c.w<=width-3&&c.y>=35&&c.y+c.h<=height-28&&!occupied.some(b=>collision(c,b,3)));
        valid.sort((a,b)=>Math.hypot(a.x+w/2-edge.mid.x,a.y+h/2-edge.mid.y)-Math.hypot(b.x+w/2-edge.mid.x,b.y+h/2-edge.mid.y));
        const chosen=valid[0];
        if(chosen){occupied.push(chosen);labels.push({...edge,...chosen,content});}
      }
      for(const l of labels){
        const g=S('g',{'data-edge-label':l.k,'data-tooltip':byId.get(edges[l.k][0]).name+' —'+l.label+'→ '+byId.get(edges[l.k][1]).name});
        if(Math.hypot(l.x+l.w/2-l.mid.x,l.y+l.h/2-l.mid.y)>32)S('line',{x1:l.mid.x,y1:l.mid.y,x2:l.x+l.w/2,y2:l.y+l.h/2,class:'map-leader',opacity:0.5},undefined,g);
        S('rect',{x:l.x,y:l.y,width:l.w,height:l.h,class:'map-label-bg'},undefined,g);
        S('text',{x:l.x+l.w/2,y:l.y+13,'text-anchor':'middle',class:'map-label-text'},l.content,g);
      }
      for(const [id,box] of boxes){
        const n=byId.get(id),g=S('g',{'data-node':id,class:'cursor-interaction','data-tooltip':n.code+' '+n.name+' · '+chapterLabel(n)});
        const nodeRect=S('rect',{x:box.x,y:box.y,width:box.w,height:box.h,rx:6,class:'map-node'+(id===selected?' selected':'')},undefined,g);
        nodeRect.setAttribute('style','fill:'+chapterFills.get(id));
        const lineTop=box.y+(compact?18:16);
        box.lines.forEach((line,i)=>S('text',{x:box.x+box.w/2,y:lineTop+i*16,'text-anchor':'middle'},line,g));
        S('text',{x:box.x+box.w/2,y:box.y+box.h-7,'text-anchor':'middle'},compact?(n.chapter==='0'?'未分章':'章 '+n.chapter):chapterLabel(n),g);
        g.addEventListener('click',()=>choose(id));
      }
      if(layout==='semantic')for(const [id,a] of anchors){
        const n=byId.get(id),chapters=chaptersOf(n);
        const fill=chapters.length===1?chapterColor(chapters[0]):chapterFills.get(id);
        S('circle',{cx:a.x,cy:a.y,r:id===selected?5:3.5,class:'map-anchor'+(id===selected?' selected':''),'data-anchor':id,style:'fill:'+fill,stroke:'var(--foreground)','stroke-width':0.7});
      }
      const legendText=layout==='relations'?'箭头文字＝明确用途 · 虚线＝结果反馈 · 粉线＝当前节点关联 · 位置用于阅读':'小圆点＝真实语义坐标 · 细线＝标签避让 · 粉线＝当前关联 · 二维距离相对误差 '+(projection.normalized_distance_error*100).toFixed(1)+'%';
      root.querySelector('#am3-legend').textContent=(compact?'N／R＝编号 · 全部文字见下方索引 · ':'')+legendText+(layout==='semantic'?' · 极坐标原点 (0,0)，每圈 0.2 投影单位':'');
      const key=root.querySelector('#am3-key');key.hidden=!compact;key.replaceChildren();
      if(compact){
        H('div','知识点编号','map-detail-title',key);const nodeGrid=H('div',undefined,'map-key-grid',key);
        for(const n of byId.values())H('div',n.code+' '+n.name,undefined,nodeGrid);
        H('div','关系编号','map-detail-title',key);const relationGrid=H('div',undefined,'map-relation-list',key);
        edges.forEach(([a,b,label],i)=>H('div','R'+String(i+1).padStart(2,'0')+' '+byId.get(a).code+' —'+label+'→ '+byId.get(b).code,undefined,relationGrid));
      }
      svg.setAttribute('data-node-count',boxes.size);svg.setAttribute('data-edge-count',edges.length);svg.setAttribute('data-label-count',labels.length);
    }

    function drawPolarGrid(origin,width,height,defs){
      const clip=S('clipPath',{id:'polar-clip'},undefined,defs);
      S('rect',{x:0,y:35,width,height:height-70},undefined,clip);
      const grid=S('g',{class:'polar-grid','clip-path':'url(#polar-clip)','aria-hidden':'true','data-polar-origin-x':origin.x,'data-polar-origin-y':origin.y,'data-polar-scale':origin.scale,'data-world-origin':'0,0'});
      const corners=[[0,35],[width,35],[0,height-35],[width,height-35]];
      const radius=Math.max(...corners.map(([x,y])=>Math.hypot(x-origin.x,y-origin.y)));
      for(let r=.2;r<=radius/origin.scale+.2;r+=.2){
        S('circle',{cx:origin.x,cy:origin.y,r:r*origin.scale,'data-polar-radius':r.toFixed(1)},undefined,grid);
        if(origin.x+r*origin.scale<width-26)S('text',{x:origin.x+r*origin.scale+4,y:origin.y-7},r.toFixed(1),grid);
      }
      for(let degrees=0;degrees<360;degrees+=30){
        const angle=degrees*Math.PI/180;
        S('line',{x1:origin.x,y1:origin.y,x2:origin.x+Math.cos(angle)*radius,y2:origin.y-Math.sin(angle)*radius,class:degrees%90===0?'polar-main':''},undefined,grid);
      }
      S('text',{x:origin.x+5,y:origin.y+14},'O',grid);
    }
    function ensureFlight(){
      if(!flight){
        const colors=Array.from({length:maxChapter},(_,i)=>getComputedStyle(root).getPropertyValue('--am3-chapter-'+(i+1)).trim());
        flight=new AgentMap3D({svg,plot,nodes:Array.from(byId.values()),edges,positions:data3d.nodes,colors,selected,onSelect:choose,onCamera:camera=>{
          const status=root.querySelector('#camera-status');
          const p=camera.position;
          status.textContent=`观察位置 (${p.map(v=>v.toFixed(2)).join(', ')}) · 视野内 ${camera.visibleCount} / ${camera.totalCount} 个知识点`;
          status.dataset.cameraX=p[0];status.dataset.cameraY=p[1];status.dataset.cameraZ=p[2];
          status.dataset.cameraYaw=camera.yaw;status.dataset.cameraPitch=camera.pitch;
        }});
      }
      return flight;
    }
    root.querySelector('#reset-camera').addEventListener('click',()=>ensureFlight().reset());
    for(const n of byId.values()){
      const button=H('button',n.code+' '+n.name,'btn',root.querySelector('#am3-all-nodes'));
      button.type='button';button.addEventListener('click',()=>choose(n.id));
    }

    function choose(id){if(!byId.has(id))return;selected=id;comparison=null;updateDetail();draw();persist();}
    nodeSelect.addEventListener('change',()=>choose(nodeSelect.value));
    layoutSelect.addEventListener('change',()=>{layout=layoutSelect.value;updateDetail();draw();persist();});
    new ResizeObserver(()=>draw()).observe(plot);
    updateDetail();draw();
  })();
  