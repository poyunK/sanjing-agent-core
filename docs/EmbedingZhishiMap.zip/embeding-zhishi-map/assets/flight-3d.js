/* 三维地图只改变观察相机。传入的知识点世界坐标始终保持不变。 */
(function () {
  'use strict';
  const NS = 'http://www.w3.org/2000/svg';
  const NEAR = 0.055;
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const add = (a, b, k = 1) => a.map((v, i) => v + b[i] * k);
  const sub = (a, b) => a.map((v, i) => v - b[i]);
  function el(tag, attrs = {}, text) {
    const n = document.createElementNS(NS, tag);
    for (const [key, value] of Object.entries(attrs)) n.setAttribute(key, String(value));
    if (text !== undefined) n.textContent = text;
    return n;
  }
  function overlap(a, b) {
    return Math.max(0, Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x)) *
      Math.max(0, Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y));
  }
  // 估算中文与西文宽度后截断；完整名称仍保存在 title 和 aria-label 中。
  function fitText(text, fontSize, width) {
    const measure = value => Array.from(value).reduce((sum, char) => sum + fontSize * (/[\u2e80-\uffff]/.test(char) ? 1 : 0.58), 0);
    if (measure(text) <= width) return text;
    let result = '';
    for (const char of Array.from(text)) {
      if (measure(result + char + '…') > width) break;
      result += char;
    }
    return result + '…';
  }

  globalThis.AgentMap3D = class AgentMap3D {
    constructor({ svg, plot, nodes, edges, positions, colors, selected, onSelect, onCamera, onReady }) {
      this.svg = svg;
      this.plot = plot;
      this.originalPlotStyle = { cursor: plot.style.cursor, touchAction: plot.style.touchAction, tabIndex: plot.getAttribute('tabindex') };
      this.nodes = nodes;
      this.edges = edges.map((edge, index) => Array.isArray(edge)
        ? { from: edge[0], to: edge[1], name: edge[2], index }
        : { from: edge.from || edge.source, to: edge.to || edge.target, name: edge.name || edge.label || '', index });
      this.positions = new Map(positions.map(p => [p.id, Object.freeze([Number(p.x), Number(p.y), Number(p.z)])]));
      this.colors = colors;
      this.selected = selected;
      this.onSelect = onSelect || (() => {});
      this.onCamera = onCamera || (() => {});
      this.active = true;
      this.destroyed = false;
      const worldPoints = [...this.positions.values()];
      this.homeTarget = [0, 1, 2].map(axis => worldPoints.reduce((sum,p)=>sum+p[axis],0)/worldPoints.length);
      const radius = Math.max(...worldPoints.map(p=>Math.hypot(...sub(p,this.homeTarget))));
      this.homeDistance = Math.max(3.4, radius / Math.sin(55*Math.PI/360) + 0.2);
      this.homePosition = add(this.homeTarget,[0,0,1],this.homeDistance);
      this.pos = [...this.homePosition];
      this.yaw = 0;
      this.pitch = 0;
      this.keys = new Set();
      this.drag = null;
      this.raf = null;
      this.lastTime = 0;
      this.uid = 'flight-' + Math.random().toString(36).slice(2, 9);
      this.handlers = [];
      this.stars = Array.from({ length: 160 }, (_, i) => {
        const y = 1 - (2 * (i + 0.5) / 160);
        const a = i * 2.399963229728653;
        const r = Math.sqrt(1 - y * y);
        return [Math.cos(a) * r, y, Math.sin(a) * r];
      });
      this._activatePlot();
      this._bind();
      this.resize();
      if (typeof ResizeObserver !== 'undefined') {
        this.observer = new ResizeObserver(() => this.resize());
        this.observer.observe(plot);
      }
      if (onReady) onReady();
    }

    get camera() {
      return Object.freeze({ position: Object.freeze([...this.pos]), yaw: this.yaw, pitch: this.pitch });
    }

    _listen(target, name, fn, options) {
      target.addEventListener(name, fn, options);
      this.handlers.push(() => target.removeEventListener(name, fn, options));
    }

    _isTyping(target) {
      return !!(target && target.closest && target.closest('input, textarea, select, button, [contenteditable="true"]'));
    }

    _focused() {
      return this.plot === document.activeElement || this.plot.contains(document.activeElement);
    }

    _activatePlot() {
      this.plot.tabIndex = 0;
      this.plot.style.touchAction = 'none';
      this.plot.style.cursor = 'grab';
    }

    _restorePlot() {
      this.plot.style.cursor = this.originalPlotStyle.cursor;
      this.plot.style.touchAction = this.originalPlotStyle.touchAction;
      if (this.originalPlotStyle.tabIndex === null) this.plot.removeAttribute('tabindex');
      else this.plot.setAttribute('tabindex', this.originalPlotStyle.tabIndex);
    }

    _stop() {
      this.keys.clear();
      this.drag = null;
      this.plot.style.cursor = this.active ? 'grab' : this.originalPlotStyle.cursor;
      this.lastTime = 0;
      if (this.raf !== null) cancelAnimationFrame(this.raf);
      this.raf = null;
    }

    _bind() {
      this._listen(this.plot, 'pointerdown', event => {
        if (!this.active || event.button !== 0 || this._isTyping(event.target)) return;
        this.plot.focus({ preventScroll: true });
        this.drag = { id: event.pointerId, x: event.clientX, y: event.clientY, moved: false, node: event.target.closest('[data-node]')?.getAttribute('data-node') };
        this.plot.setPointerCapture(event.pointerId);
        this.plot.style.cursor = 'grabbing';
        event.preventDefault();
      });
      this._listen(this.plot, 'pointermove', event => {
        if (!this.active || !this.drag || this.drag.id !== event.pointerId) return;
        const dx = event.clientX - this.drag.x;
        const dy = event.clientY - this.drag.y;
        if (Math.abs(dx) + Math.abs(dy) > 1) this.drag.moved = true;
        this.drag.x = event.clientX;
        this.drag.y = event.clientY;
        this.yaw += dx * 0.004;
        this.pitch = clamp(this.pitch - dy * 0.004, -1.45, 1.45);
        this._request();
      });
      const pointerEnd = event => {
        if (!this.drag || this.drag.id !== event.pointerId) return;
        const click = !this.drag.moved && this.drag.node;
        this.drag = null;
        this.plot.style.cursor = 'grab';
        if (this.plot.hasPointerCapture(event.pointerId)) this.plot.releasePointerCapture(event.pointerId);
        if (click) { this.setSelected(click); this.onSelect(click); }
      };
      this._listen(this.plot, 'pointerup', pointerEnd);
      this._listen(this.plot, 'pointercancel', () => this._stop());
      this._listen(this.plot, 'lostpointercapture', () => { this.drag = null; this.plot.style.cursor = this.active ? 'grab' : this.originalPlotStyle.cursor; });
      this._listen(this.plot, 'keydown', event => {
        if (!this.active || !this._focused() || this._isTyping(event.target)) return;
        const key = event.key.toLowerCase();
        if (['w', 'a', 's', 'd', 'q', 'e', 'shift'].includes(key)) {
          event.preventDefault(); this.keys.add(key); this._request();
        } else if (key === 'escape') { this._stop(); this.plot.blur(); }
      });
      this._listen(window, 'keyup', event => this.keys.delete(event.key.toLowerCase()));
      this._listen(this.plot, 'focusout', event => { if (!this.plot.contains(event.relatedTarget)) this._stop(); });
      this._listen(window, 'blur', () => this._stop());
      this._listen(document, 'visibilitychange', () => { if (document.hidden) this._stop(); });
      this._listen(this.plot, 'wheel', event => {
        if (!this.active || !this._focused() || this._isTyping(event.target)) return;
        event.preventDefault();
        const amount = clamp(event.deltaY * (event.deltaMode ? 0.08 : 0.0025), -0.5, 0.5);
        this.pos = add(this.pos, this._basis().forward, -amount);
        this.draw();
      }, { passive: false });
    }

    _basis() {
      const s = Math.sin(this.yaw), c = Math.cos(this.yaw), sp = Math.sin(this.pitch), cp = Math.cos(this.pitch);
      return { forward: [s * cp, sp, -c * cp], right: [c, 0, s], up: [-s * sp, cp, c * sp] };
    }

    _cameraPoint(world, directionOnly = false) {
      const b = this._basis();
      const v = directionOnly ? world : sub(world, this.pos);
      return [dot(v, b.right), dot(v, b.up), dot(v, b.forward)];
    }

    _project(cameraPoint) {
      if (cameraPoint[2] < NEAR) return null;
      return { x: this.w / 2 + cameraPoint[0] * this.focal / cameraPoint[2], y: this.h / 2 - cameraPoint[1] * this.focal / cameraPoint[2], depth: cameraPoint[2] };
    }

    _projectWorld(world) { return this._project(this._cameraPoint(world)); }

    _segment(worldA, worldB, directionOnly = false) {
      let a = this._cameraPoint(worldA, directionOnly), b = this._cameraPoint(worldB, directionOnly);
      if (a[2] < NEAR && b[2] < NEAR) return null;
      if (a[2] < NEAR) { a = add(a, sub(b, a), (NEAR - a[2]) / (b[2] - a[2])); a[2] = NEAR; }
      if (b[2] < NEAR) { b = add(b, sub(a, b), (NEAR - b[2]) / (a[2] - b[2])); b[2] = NEAR; }
      const pa = this._project(a), pb = this._project(b);
      if (!pa || !pb) return null;
      return [pa, pb];
    }

    _request() {
      if (!this.active || this.destroyed || this.raf !== null) return;
      this.raf = requestAnimationFrame(time => {
        this.raf = null;
        const dt = this.lastTime ? Math.min((time - this.lastTime) / 1000, 0.05) : 0;
        this.lastTime = time;
        const basis = this._basis();
        let movement = [0, 0, 0];
        for (const [key, direction, sign] of [['w', basis.forward, 1], ['s', basis.forward, -1], ['d', basis.right, 1], ['a', basis.right, -1], ['e', [0, 1, 0], 1], ['q', [0, 1, 0], -1]]) {
          if (this.keys.has(key)) movement = add(movement, direction, sign);
        }
        const length = Math.hypot(...movement);
        if (length) this.pos = add(this.pos, movement, 0.75 * dt * (this.keys.has('shift') ? 3 : 1) / length);
        this.draw();
        if (length) this._request(); else this.lastTime = 0;
      });
    }

    resize() {
      if (this.destroyed || !this.active) return;
      const rect = this.plot.getBoundingClientRect();
      this.w = Math.max(240, rect.width);
      this.h = Math.max(320, rect.height || 700);
      // 较短屏幕边的视角为 55°，使窄窗口也能保留初始全图。
      this.focal = Math.min(this.w, this.h) / (2 * Math.tan(55 * Math.PI / 360));
      this.svg.setAttribute('viewBox', `0 0 ${this.w} ${this.h}`);
      this.draw();
    }

    setSelected(id) { this.selected = id; if (this.active) this.draw(); }
    reset() { this._stop(); this.pos = [...this.homePosition]; this.yaw = 0; this.pitch = 0; if (this.active) this.draw(); }
    setActive(value) {
      if (this.destroyed) return;
      this.active = !!value;
      if (!this.active) { this._stop(); this._restorePlot(); }
      else { this._activatePlot(); this.resize(); }
    }
    destroy() { this.active = false; this.destroyed = true; this._stop(); this._restorePlot(); this.handlers.forEach(fn => fn()); if (this.observer) this.observer.disconnect(); }

    _sky(defs) {
      const gradient = el('radialGradient', { id: this.uid + '-sky', cx: '50%', cy: '36%', r: '80%' });
      gradient.append(el('stop', { offset: '0%', 'stop-color': '#343747' }), el('stop', { offset: '100%', 'stop-color': '#1d202c' }));
      defs.append(gradient);
      const sky = el('g', { class: 'am3-skybox', 'data-env': 'skybox', 'data-sky': 'direction-fixed', 'pointer-events': 'none' });
      sky.append(el('rect', { x: 0, y: 0, width: this.w, height: this.h, fill: `url(#${this.uid}-sky)` }));
      this.stars.forEach((direction, i) => {
        const p = this._project(this._cameraPoint(direction, true));
        if (p && p.x > 0 && p.x < this.w && p.y > 0 && p.y < this.h) sky.append(el('circle', { cx: p.x, cy: p.y, r: i % 13 === 0 ? 1.3 : 0.7, fill: '#d4d2e6', opacity: i % 13 === 0 ? 0.4 : 0.17, 'data-sky-direction': direction.join(',') }));
      });
      for (let i = 0; i < 128; i++) {
        const a = i / 128 * Math.PI * 2, b = (i + 1) / 128 * Math.PI * 2;
        const s = this._segment([Math.cos(a), 0, Math.sin(a)], [Math.cos(b), 0, Math.sin(b)], true);
        if (s) sky.append(el('line', { x1: s[0].x, y1: s[0].y, x2: s[1].x, y2: s[1].y, stroke: '#a8aec9', 'stroke-width': 0.8, opacity: 0.15 }));
      }
      for (const [name, direction] of [['北 · −Z', [0, 0, -1]], ['东 · +X', [1, 0, 0]], ['南 · +Z', [0, 0, 1]], ['西 · −X', [-1, 0, 0]], ['上 · +Y', [0, 1, 0]], ['下 · −Y', [0, -1, 0]]]) {
        const p = this._project(this._cameraPoint(direction, true));
        if (p && p.x > 24 && p.x < this.w - 24 && p.y > 24 && p.y < this.h - 24) sky.append(el('text', { x: p.x, y: p.y - 12, fill: '#b7bccf', opacity: 0.46, 'font-size': 12, 'text-anchor': 'middle', 'data-sky-label': name }, name));
      }
      return sky;
    }

    _reference() {
      const group = el('g', { class: 'am3-floor', 'data-env': 'floor-and-axes', 'pointer-events': 'none', 'data-reference': 'world-fixed', 'clip-path': `url(#${this.uid}-clip)` });
      const drawLine = (a, b, attrs) => {
        const s = this._segment(a, b);
        if (s) group.append(el('line', { x1: s[0].x, y1: s[0].y, x2: s[1].x, y2: s[1].y, ...attrs }));
      };
      for (let k = -10; k <= 10; k++) {
        const value = k * 0.5;
        const attrs = { stroke: '#949cb5', 'stroke-width': k === 0 ? 1 : 0.6, opacity: k === 0 ? 0.24 : 0.1 };
        drawLine([value, -1.12, -5], [value, -1.12, 5], attrs);
        drawLine([-5, -1.12, value], [5, -1.12, value], attrs);
      }
      for (const [name, end, color] of [['X', [1.35, 0, 0], '#e0a2bb'], ['Y', [0, 1.35, 0], '#a0c7b2'], ['Z', [0, 0, 1.35], '#a4b8df']]) {
        drawLine([0, 0, 0], end, { stroke: color, opacity: 0.36, 'stroke-width': 1, 'stroke-dasharray': '4 5' });
        const p = this._projectWorld(end);
        if (p) group.append(el('text', { x: p.x + 6, y: p.y - 6, fill: color, opacity: 0.65, 'font-size': 12 }, name));
      }
      return group;
    }

    _labels(points) {
      const placed = [];
      const ordered = [...points].sort((a, b) => (a.node.id === this.selected ? -1 : b.node.id === this.selected ? 1 : a.p.depth - b.p.depth));
      for (const point of ordered) {
        const scale = clamp(this.homeDistance / point.p.depth, 0.88, 1.45);
        const compact = this.w < 580;
        const w = (compact ? 76 : 166) * scale, h = 48 * scale;
        let best = null, bestScore = Infinity;
        for (const radius of [0, 44, 76, 112, 154, 200]) {
          for (let d = 0; d < (radius ? 12 : 1); d++) {
            const angle = d / 12 * Math.PI * 2;
            const candidate = { x: clamp(point.p.x - w / 2 + Math.cos(angle) * radius, 8, Math.max(8, this.w - w - 8)), y: clamp(point.p.y - h / 2 + Math.sin(angle) * radius, 8, Math.max(8, this.h - h - 8)), w, h, scale, compact };
            const score = placed.reduce((sum, other) => sum + overlap(candidate, other) * 24, 0) + Math.hypot(candidate.x + w / 2 - point.p.x, candidate.y + h / 2 - point.p.y);
            if (score < bestScore) { bestScore = score; best = candidate; }
          }
        }
        point.label = best;
        placed.push(best);
      }
      // 后续小幅避让只移动标签，绝不移动语义圆点或世界坐标。
      for (let pass = 0; pass < 20; pass++) {
        for (let i = 0; i < ordered.length; i++) for (let j = i + 1; j < ordered.length; j++) {
          const a = ordered[i].label, b = ordered[j].label;
          const dx = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x);
          const dy = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
          if (dx > 0 && dy > 0) {
            const axis = dx < dy ? 'x' : 'y', delta = (axis === 'x' ? dx : dy) / 2 + 2;
            const sign = a[axis] < b[axis] ? -1 : 1;
            a[axis] += sign * delta; b[axis] -= sign * delta;
            a.x = clamp(a.x, 8, Math.max(8, this.w - a.w - 8)); b.x = clamp(b.x, 8, Math.max(8, this.w - b.w - 8));
            a.y = clamp(a.y, 8, Math.max(8, this.h - a.h - 8)); b.y = clamp(b.y, 8, Math.max(8, this.h - b.h - 8));
          }
        }
      }
    }

    _edgeLabels(records, points) {
      const inflate = rect => ({ x: rect.x - 5, y: rect.y - 5, w: rect.w + 10, h: rect.h + 10 });
      const occupied = points.flatMap(point => [inflate(point.label), { x: point.p.x - 8, y: point.p.y - 8, w: 16, h: 16 }]);
      const placed = [];
      for (const record of records) {
        const text = this.w < 580 ? 'R' + String(record.edge.index + 1).padStart(2, '0') : record.edge.name;
        const width = Array.from(text).reduce((sum, char) => sum + (/[\u2e80-\uffff]/.test(char) ? 12 : 7), 0) + 16;
        const w = Math.min(this.w - 16, Math.max(40, width)), h = 24;
        let best = null, bestScore = Infinity, bestOverlap = Infinity;
        const consider = (cx, cy) => {
          const rect = { x: clamp(cx - w / 2, 8, this.w - w - 8), y: clamp(cy - h / 2, 8, this.h - h - 8), w, h };
          const collision = occupied.reduce((sum, item) => sum + overlap(rect, item), 0);
          const distance = Math.hypot(rect.x + w / 2 - record.anchor.x, rect.y + h / 2 - record.anchor.y);
          const score = collision * 2500 + distance;
          if (score < bestScore) { bestScore = score; bestOverlap = collision; best = rect; }
        };
        for (const radius of [0, 28, 48, 76, 112, 154, 200, 260]) {
          for (let d = 0; d < (radius ? 16 : 1); d++) {
            const angle = d / 16 * Math.PI * 2;
            consider(record.anchor.x + Math.cos(angle) * radius, record.anchor.y + Math.sin(angle) * radius);
          }
        }
        // 极近视角或窄窗口中，检查整个画布的剩余空隙作为兜底。
        if (bestOverlap > 0) {
          for (let y = 8 + h / 2; y <= this.h - h / 2 - 8; y += 24) {
            for (let x = 8 + w / 2; x <= this.w - w / 2 - 8; x += 24) consider(x, y);
          }
        }
        if (bestOverlap > 0) {
          const xs = [...new Set([8 + w / 2, this.w - w / 2 - 8, ...occupied.flatMap(item => [item.x - w / 2 - 1, item.x + item.w + w / 2 + 1])])];
          const ys = [...new Set([8 + h / 2, this.h - h / 2 - 8, ...occupied.flatMap(item => [item.y - h / 2 - 1, item.y + item.h + h / 2 + 1])])];
          for (const y of ys) for (const x of xs) consider(x, y);
        }
        // 空间不足时保留实际关系线，文字由页面完整关系索引承接，避免覆盖知识点。
        if (bestOverlap > 0.01) continue;
        const result = { ...record, rect: best, text };
        occupied.push(inflate(best));
        placed.push(result);
      }
      return placed;
    }

    draw() {
      if (!this.active || this.destroyed || !this.w) return;
      const fragment = document.createDocumentFragment();
      const defs = el('defs');
      const clip = el('clipPath', { id: this.uid + '-clip' });
      clip.append(el('rect', { x: 0, y: 0, width: this.w, height: this.h }));
      defs.append(clip);
      const marker = el('marker', { id: this.uid + '-arrow', markerWidth: 6, markerHeight: 6, refX: 5, refY: 3, orient: 'auto', markerUnits: 'userSpaceOnUse' });
      marker.append(el('path', { d: 'M0 0 L6 3 L0 6', fill: 'none', stroke: '#a5a7b9', 'stroke-width': 0.8 }));
      defs.append(marker);
      fragment.append(defs, this._sky(defs), this._reference());
      const points = [];
      for (const node of this.nodes) {
        const world = this.positions.get(node.id);
        if (!world) continue;
        const p = this._projectWorld(world);
        if (p && p.x >= -10 && p.x <= this.w + 10 && p.y >= -10 && p.y <= this.h + 10) points.push({ node, world, p });
      }
      this._labels(points);
      const edgeGroup = el('g', { 'clip-path': `url(#${this.uid}-clip)`, 'pointer-events': 'none' });
      const edgeRecords = [];
      for (const edge of this.edges) {
        const from = this.positions.get(edge.from), to = this.positions.get(edge.to);
        if (!from || !to) continue;
        const segment = this._segment(from, to);
        if (!segment) continue;
        const highlight = edge.from === this.selected || edge.to === this.selected;
        edgeGroup.append(el('line', { x1: segment[0].x, y1: segment[0].y, x2: segment[1].x, y2: segment[1].y, stroke: highlight ? '#ffb0da' : '#a5a7b9', opacity: highlight ? 0.85 : 0.25, 'stroke-width': highlight ? 1.8 : 0.8, 'marker-end': `url(#${this.uid}-arrow)`, 'data-edge': edge.index, 'data-from': edge.from, 'data-to': edge.to }));
        if (highlight) {
          const x = (segment[0].x + segment[1].x) / 2, y = (segment[0].y + segment[1].y) / 2;
          if (x > 8 && x < this.w - 8 && y > 8 && y < this.h - 8) edgeRecords.push({ edge, anchor: { x, y } });
        }
      }
      for (const { edge, anchor, rect, text } of this._edgeLabels(edgeRecords, points)) {
        const cx = rect.x + rect.w / 2, cy = rect.y + rect.h / 2;
        const labelGroup = el('g', { 'data-relation-label': edge.index });
        labelGroup.append(el('title', {}, edge.name));
        if (Math.hypot(cx - anchor.x, cy - anchor.y) > 14) labelGroup.append(el('line', { x1: anchor.x, y1: anchor.y, x2: cx, y2: cy, stroke: '#ffb0da', 'stroke-width': 0.65, opacity: 0.45, 'data-edge-tether': edge.index }));
        labelGroup.append(el('rect', { x: rect.x, y: rect.y, width: rect.w, height: rect.h, rx: 5, fill: '#242733', 'fill-opacity': 0.94, stroke: '#ffb0da', 'stroke-opacity': 0.3, 'stroke-width': 0.7, 'data-edge-label-box': edge.index }));
        labelGroup.append(el('text', { x: cx, y: cy + 4, fill: '#ffe1f1', 'font-size': 12, 'text-anchor': 'middle', 'data-edge-label': edge.index }, text));
        edgeGroup.append(labelGroup);
      }
      fragment.append(edgeGroup);
      points.sort((a, b) => b.p.depth - a.p.depth || (a.node.id === this.selected ? 1 : 0));
      const nodeGroup = el('g', { 'clip-path': `url(#${this.uid}-clip)` });
      for (const { node, world, p, label } of points) {
        const chapters = (String(node.chapter).match(/\d+/g) || ['1']).map(Number);
        const color = this.colors[(chapters[0] - 1) % this.colors.length] || '#b8b6c5';
        const secondColor = this.colors[((chapters[1] || chapters[0]) - 1) % this.colors.length] || color;
        const gradient = el('linearGradient', { id: this.uid + '-node-' + node.id, x1: '0%', x2: '100%', y1: '0%', y2: '0%' });
        chapters.forEach((chapter,i)=>{const fill=this.colors[chapter-1]||'#b8b6c5';gradient.append(el('stop',{offset:(i/chapters.length*100)+'%','stop-color':fill}),el('stop',{offset:((i+1)/chapters.length*100)+'%','stop-color':fill}));});
        defs.append(gradient);
        const group = el('g', { 'data-node': node.id, 'data-world-x': world[0], 'data-world-y': world[1], 'data-world-z': world[2], 'data-depth': p.depth, 'data-label-scale': label.scale, 'data-label-mode': label.compact ? 'compact' : 'name', role: 'button', tabindex: '-1', 'aria-label': `${node.name}，第${node.chapter}章` });
        group.append(el('title', {}, `${node.name} · 第 ${chapters.join('、')} 章`));
        group.append(el('line', { x1: p.x, y1: p.y, x2: label.x + label.w / 2, y2: label.y + label.h / 2, stroke: color, opacity: 0.45, 'stroke-width': 0.7, 'pointer-events': 'none' }));
        group.append(el('rect', { x: label.x, y: label.y, width: label.w, height: label.h, rx: 8, fill: `url(#${this.uid}-node-${node.id})`, 'fill-opacity': 0.25, stroke: node.id === this.selected ? '#ffb0da' : '#c7cbdf', 'stroke-opacity': node.id === this.selected ? 1 : 0.13, 'stroke-width': node.id === this.selected ? 2 : 0.8 }));
        group.append(el('circle', { cx: p.x, cy: p.y, r: (node.id === this.selected ? 5 : 3.5) * clamp(this.homeDistance / p.depth, 0.6, 1.6), fill: `url(#${this.uid}-node-${node.id})`, stroke: '#f4eff8', 'stroke-width': 0.7, 'data-anchor': node.id, 'data-world-x': world[0], 'data-world-y': world[1], 'data-world-z': world[2] }));
        const code = node.code || 'N' + String((node.index ?? this.nodes.indexOf(node)) + 1).padStart(2, '0');
        const mainFont = Math.max(12, 13 * label.scale), chapterFont = Math.max(11, 11 * label.scale);
        const mainText = label.compact ? code : fitText(`${code} ${node.name}`, mainFont, label.w - 14);
        group.append(el('text', { x: label.x + label.w / 2, y: label.y + 20 * label.scale, 'text-anchor': 'middle', fill: '#f6f4ff', 'font-size': mainFont, 'pointer-events': 'none' }, mainText));
        group.append(el('text', { x: label.x + label.w / 2, y: label.y + 37 * label.scale, 'text-anchor': 'middle', fill: '#e3deec', 'font-size': chapterFont, 'pointer-events': 'none' }, chapters[0]===0?'未分章':`第 ${chapters.join('、')} 章`));
        nodeGroup.append(group);
      }
      fragment.append(nodeGroup);
      this.svg.replaceChildren(fragment);
      this.svg.setAttribute('data-renderer', 'perspective-flight');
      this.svg.setAttribute('data-visible-nodes', String(points.length));
      this.onCamera({ position: [...this.pos], yaw: this.yaw, pitch: this.pitch, visibleCount: points.length, totalCount: this.nodes.length });
    }
  };
})();
