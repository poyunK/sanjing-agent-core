# 数据约定与运行入口

## 源数据

`assets/example-source.json` 是六点、六边的完整示例，来自本次 Agent 教材节选。新地图替换范围、节点、关系和阅读 rows；不要把演示选择当作学习者当前进度。

```json
{
  "title": "资料知识地图",
  "scope": "材料名称与覆盖范围",
  "nodes": [
    {"id":"first", "name":"概念名称", "description":"短定义与边界", "chapter":"1", "example":"小例子"}
  ],
  "edges": [["first", "second", "用途文字", "用于"]],
  "layout": {"rows": [["first", "second"]]}
}
```

上面仅展示字段结构，实际至少需要两个节点，且边的端点必须真实存在。也接受关系对象 `{source,target,label,type}`，由脚本统一为四元素数组。`sources` 可以保存文件、章节、页码与行号对象。

`chapter` 接受数字字符串或 `chapters` 数字列表。顺序用于颜色带顺序；两章左右各半，更多章等宽色带。没有章节时保留 `0`，显示“未分章”，不能猜一个真实章节。`layout.rows` 可省略，省略时按节点输入顺序每行三列；当前模板显式 rows 每行最多三点、每点恰好出现一次。

可用 `chapter_colors` 对象定制颜色，例如 `{"1":"#ffb0da","2":"#73d38e"}`。主题分组不是原资料章节时，应在 scope 中说明编号是本地图整理的分组，不冒称材料本来的章节。

## 一次完整制作

下面的解释器和权重路径是本机已验证环境。技能路径是当前注册位置；换机器时更改这三个路径即可。先用新输出目录，避免覆盖旧地图。

```powershell
$mapPython = '<WeMM项目目录>\.venv-embed\Scripts\python.exe'
$mapSkill = '<技能目录>'
$mapWeights = '<WeMM项目目录>\models\tencent\WeMM-Embedding-2B'
$mapSource = Join-Path $mapSkill 'assets\example-source.json'
$mapOutput = '<工作区>\新的知识地图'

& $mapPython -X utf8 (Join-Path $mapSkill 'scripts\embed_wemm.py') --source $mapSource --weights $mapWeights --out-dir $mapOutput
& $mapPython -X utf8 (Join-Path $mapSkill 'scripts\project_map.py') --source $mapSource --vectors (Join-Path $mapOutput 'embeddings.npy') --out-dir $mapOutput --dimensions 2 3 --starts 8
& $mapPython -X utf8 (Join-Path $mapSkill 'scripts\build_html.py') --data (Join-Path $mapOutput 'knowledge-map.json') --data3d (Join-Path $mapOutput 'knowledge-map-3d.json') --out (Join-Path $mapOutput '知识地图.html')
& $mapPython -X utf8 (Join-Path $mapSkill 'scripts\validate_map.py') --source $mapSource --vectors (Join-Path $mapOutput 'embeddings.npy') --data (Join-Path $mapOutput 'knowledge-map.json') --data3d (Join-Path $mapOutput 'knowledge-map-3d.json') --html (Join-Path $mapOutput '知识地图.html')
```

`embed_wemm.py` 在文本与模型一致时直接复用缓存；需要重算时用新目录或 `--recompute`。投影已有结果时默认不覆盖，可在保留旧版后用 `--overwrite`。只新增三维用 `--dimensions 3`；解析导数精修加 `--refine`。

只改颜色和页面：修改源定义以外的展示字段或资产，再运行 `build_html.py`。若改 chapter、layout 等源元数据，要同步到现有 2D JSON 的对应元数据，保持名称、定义、向量与坐标不变；不要因为页面重建重算模型。

## 不使用嵌入的关系图

```powershell
& $mapPython -X utf8 (Join-Path $mapSkill 'scripts\build_html.py') --source $mapSource --out (Join-Path $mapOutput '关系总览.html')
```

这个模式明确禁用语义布局，不提供伪造的向量、相似度或坐标。打包页面只需要 Python 标准库；向量与投影步骤另需相应依赖。也可以直接依据相同数据写静态 Mermaid。

## 文件之间的关系

| 文件 | 含义 |
|---|---|
| knowledge-map-source.json | 人工整理的节点、定义、关系与来源 |
| embeddings.npy | 保存真实模型输出后归一化的向量 |
| embedding-record.json | 输入、模型、编码与向量文件的关联记录 |
| knowledge-map.json | 二维坐标、原始距离、质量与展示元数据 |
| knowledge-map-3d.json | 同一输入的三维坐标与空间质量 |
| 知识地图.html | 所有前端程序、样式和所需数据内嵌的独立页面 |

模板内部的 `am3-*` 元素 ID 与 `AgentMap3D` 类名来自本次原型，不限制资料领域。完整资产已经在技能内，生成时不依赖原 Codex 对话目录或原项目。
