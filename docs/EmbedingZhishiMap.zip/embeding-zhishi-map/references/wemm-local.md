# 本地 WeMM 用法

## 本机已经验证的环境

以下是 2026-10-13 检查到的路径示例，执行前仍要确认存在；脚本不会把这些路径写死。

```text
解释器：<WeMM项目目录>\.venv-embed\Scripts\python.exe
权重：<WeMM项目目录>\models\tencent\WeMM-Embedding-2B
```

当前可用组合：Python 3.13；torch `2.11.0+cu128`、transformers `5.2.0`、sentence-transformers `5.7.0`、qwen-vl-utils `0.0.14`、accelerate `1.14.0`、NumPy `2.5.2`、SciPy `1.18.1`、scikit-learn `1.9.0`。CUDA 可用。它们是已验证环境，不是任何机器都必须安装的唯一版本。

WeMM-Embedding-2B 可通过 Sentence Transformers 使用，并输出 2048 维向量；本地图使用纯文本输入。官方模型用法见 [Tencent 模型卡](https://huggingface.co/tencent/WeMM-Embedding-2B)。

## 最小调用

模型目录包含自己的 Python 实现，`trust_remote_code=True` 会执行这些模型代码。使用已核对来源的本地权重；不把陌生目录当作普通数据随意加载。这里的“remote code”选项不意味着必须联网。

```python
import torch
from sentence_transformers import SentenceTransformer

model = SentenceTransformer(
    str(weights_path),
    trust_remote_code=True,
    local_files_only=True,
    device="cuda",
    model_kwargs={"dtype": torch.bfloat16},
)
model.eval()
with torch.inference_mode():
    vectors = model.encode_document(
        texts, batch_size=2, normalize_embeddings=True,
        convert_to_numpy=True,
    )
```

把所有知识点当作同一类文档编码。不要部分使用 `encode_query`、部分使用 `encode_document` 再混成同一个距离矩阵；检索问题与知识文档明确不同的场景才分别编码，并单独验证。通用接口对这些方法的说明见 [Sentence Transformers 文档](https://www.sbert.net/docs/package_reference/sentence_transformer/model.html)。

## 脚本的处理

`scripts/embed_wemm.py` 接收 `--source`、`--weights`、`--out-dir`，默认离线、本地 CUDA、batch size 2。离线开关和缓存路径在导入相关库之前设置。没有自动下载、自动安装、付费 API 或伪向量降级。

输出：

- `embeddings.npy`：按节点顺序保存的 float32 向量。
- `embedding-record.json`：节点 ID 顺序、实际输入哈希、编码方法、模型指纹、维数、dtype、设备、包版本与向量文件哈希。

推理后在 float32 中再次 L2 归一化。bfloat16 的归一化存在小舍入误差；计算点积和距离前应统一处理。检查有限数值、非零范数、节点数与 2048 维，不只看“程序没报错”。

模型指纹覆盖配置、分词文件、自定义代码的 SHA256，以及权重文件名、大小、修改时间。它用于缓存识别，**不是整份权重的密码学完整性认证**。需要严密认证时另外计算权重内容哈希。修改模型、输入文本或编码方式后不能复用旧缓存；只有颜色、来源位置和阅读布局变化时可以复用。

默认 batch size 2 来自本次机器的小批量运行经验。显存不足时先降到 1，再缩短不必要的定义内容；不要把“知识名称＋定义”偷偷换成只有名称。CPU 用 `--device cpu --dtype float32`，速度需实测，当前 GPU 验证不能代替 CPU 验证。

模型卡中的可变长度嵌入属于另外一种表示选择：若用 Matryoshka 截断维数，应确认配置允许的维数，截断后重新归一化并重新建立距离、缓存与质量指标。不能把 2048 维与截断向量混用。

## 故障定位

| 现象 | 先检查 |
|---|---|
| `encode_document` 不存在 | 当前解释器和 sentence-transformers 版本；不要绕过接口制造假向量 |
| 自定义模型类导入失败 | 模型目录中的 modules.json、modeling_st_wemm.py，以及缓存位置 |
| dtype / 模型配置报错 | 本地模型实现要求的 transformers 与 torch；先复用可用解释器 |
| CUDA OOM | batch size、文本长度、其他占用显存的进程 |
| 缓存不匹配 | 输入、ID 顺序、模型指纹、编码方法；换新输出目录或明确重新计算 |
| 想补图片知识点 | 先定义图片如何和文字共同代表该概念，检查多模态输入与原纯文本分数是否仍可比较；当前文本脚本不自动读取图片 |
